import React from 'react'

export default function Logo() {
    return (
    <div className="d-flex justify-content-center">   
    <img src="/images/Logocopy.jpg" className="img-fluid"  alt="Responsive"></img>
    </div>
    )
}