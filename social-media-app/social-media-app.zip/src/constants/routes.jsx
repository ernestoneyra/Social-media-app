
export const DASHBOARD = '/';
export const SIGN_UP = '/sign-up';
export const PROFILE = '/p/:username';
export const LOGIN = '/login';
export const NOT_FOUND = '/not-found';
export const RESET_PASSWORD = '/reset-password'
export const UPDATE_PROFILE = '/update-profile'
export const CREATE_POST = '/create-post'
